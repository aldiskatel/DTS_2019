package com.aldiskatel.aplikasisqlite;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.aldiskatel.aplikasisqlite.Helper.DbHelper;

public class AddEdit extends AppCompatActivity {
    EditText txtId,txtName,txtAddress;
    Button btnSubmit,btnCanlce;
    DbHelper SQLite=new DbHelper(this);
    String id,name,address;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        txtId= (EditText) findViewById(R.id.textId);
        txtName= (EditText) findViewById(R.id.textNama);
        txtAddress= (EditText) findViewById(R.id.textAlamat);
        btnSubmit=(Button) findViewById(R.id.btnSubmit);
        btnCanlce=(Button) findViewById(R.id.btnCancle);

        id=getIntent().getStringExtra(MainActivity.TAG_ID);
        name=getIntent().getStringExtra(MainActivity.TAG_name);
        address=getIntent().getStringExtra(MainActivity.TAG_ADDRESS);

        if(id==null || id==""){
            setTitle("Add Data");
        }else {
            setTitle("Edit Data");
            txtId.setText(id);
            txtName.setText(name);
            txtAddress.setText(address);
        }
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(txtId.getText().toString().equals("")){
                        save();
                    }else {
                        edit();
                    }
                }catch (Exception e){
                    Log.e("SUbmit",e.toString());
                }
            }
        });
        btnCanlce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                blank();
                finish();
            }
        });
    }

    private void save() {
        if(String.valueOf(txtName.getText()).equals(null) || String.valueOf(txtName.getText()).equals("") ||
                String.valueOf(txtAddress.getText()).equals(null) || String.valueOf(txtAddress.getText()).equals("")){
            Toast.makeText(this, "Mohon isi semua data!", Toast.LENGTH_SHORT).show();
        }else {
            SQLite.insert(txtName.getText().toString().trim(),txtAddress.getText().toString().trim());
            blank();
            finish();
        }
    }

    private void edit() {
        if(String.valueOf(txtName.getText()).equals(null) || String.valueOf(txtName.getText()).equals("") ||
                String.valueOf(txtAddress.getText()).equals(null) || String.valueOf(txtAddress.getText()).equals("")){
            Toast.makeText(this, "Mohon isi semua data!", Toast.LENGTH_SHORT).show();
        }else {
            SQLite.update(Integer.parseInt(txtId.getText().toString().trim()),txtName.getText().toString().trim(),txtAddress.getText().toString().trim());
            blank();
            finish();
        }
    }

    private void blank() {
        txtId.setText("");
        txtName.setText("");
        txtAddress.setText("");
        txtName.requestFocus();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
