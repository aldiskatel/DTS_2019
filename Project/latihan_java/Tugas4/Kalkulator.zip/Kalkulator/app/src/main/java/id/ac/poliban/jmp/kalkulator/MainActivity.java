package id.ac.poliban.jmp.kalkulator;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnTambah,btnKurang,btnKali,btnBagi,btnBersih;
    private EditText edt1,edt2;
    private TextView tvHasil;
    private Double e1,e2,hasil;
    private String stat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inisiasi();
    }

    private void inisiasi() {
        btnTambah   = findViewById(R.id.btnTambah);
        btnKurang   = findViewById(R.id.btnKurang);
        btnKali     = findViewById(R.id.btnKali);
        btnBagi     = findViewById(R.id.btnBagi);
        edt1        = findViewById(R.id.edt1);
        edt2        = findViewById(R.id.edt2);
        tvHasil     = findViewById(R.id.textView3);
        btnBersih   = findViewById(R.id.btnBersihkan);

        action();
    }
    private void action() {
        btnTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
                hasil=e1+e2;
                stat="Penjumlahan";
                next();
            }
        });
        btnKurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
                hasil=e1-e2;
                stat="Pengurangan";
                next();
            }
        });
        btnKali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
                hasil=e1*e2;
                stat="Perkalian";
                next();
            }
        });
        btnBagi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
                hasil=e1/e2;
                stat="Pembagian";
                next();
            }
        });
        btnBersih.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt1.setText("");
                edt2.setText("");
                edt1.requestFocus();
            }
        });
    }
    public void getData(){
        e1=Double.parseDouble(String.valueOf(edt1.getText()));
        e2=Double.parseDouble(String.valueOf(edt2.getText()));
    }

    @SuppressLint("SetTextI18n")
    private void next() {
        tvHasil.setText("Hasil "+stat+" dari "+e1+" dan "+e2+" adalah \n="+hasil);
    }

    @Override
    protected void onStart(){
        super.onStart();
        btnBersih.performClick();
    }
}
