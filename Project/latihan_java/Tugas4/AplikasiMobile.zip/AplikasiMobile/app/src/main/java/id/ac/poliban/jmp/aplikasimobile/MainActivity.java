package id.ac.poliban.jmp.aplikasimobile;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText eNama;
    private Button btnTampil,btnLabel;
    private TextView lbHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inisiasi();
    }

    private void inisiasi() {
        eNama=findViewById(R.id.edtNama);
        btnTampil=findViewById(R.id.btnTampil);
        btnLabel=findViewById(R.id.btnLabel);
        lbHasil=findViewById(R.id.lblHasil);

        hajar();
    }

    private void hajar() {
        btnTampil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Nama beliau adalah \n"+eNama.getText(),Toast.LENGTH_LONG).show();
            }
        });
        btnLabel.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                lbHasil.setText("Nama beliau adalah \n"+eNama.getText());
            }
        });
    }
}
